package c11

import java.awt.*
import org.jcsp.lang.*
import org.jcsp.awt.*
import org.jcsp.groovy.*
 
class ControllerUI implements CSProcess {
  
  def ChannelInput factor
  def ChannelInput data
  def ChannelOutput suspend
  def ChannelOutput injector
  
  void run() {
	def root = new ActiveClosingFrame("Scaling System")
	def main = root.getActiveFrame()
	def suspendButton = new ActiveButton(null, suspend, "Suspend")
	def factorLabel = new Label("Old scaling factor: ")
	def factorValue = new ActiveLabel(factor)
	def injectLabel = new Label("Insert new factor:")
	def inText = new ActiveTextEnterField(null, injector)
	def outText = new ActiveTextArea(data, null)
	def container = new Container()
	container.setLayout ( new GridLayout(1,5) )
	container.add (suspendButton)
	container.add (factorLabel)
	container.add (factorValue)
	container.add (injectLabel)
	container.add (inText.getActiveTextField())
	main.setLayout(new BorderLayout())
	main.add(outText, BorderLayout.CENTER)
	main.add(container, BorderLayout.SOUTH)
	main.pack()
	main.setVisible(true)
	def network = [root, factorValue, inText, outText, suspendButton]
  	new PAR (network).run()
  }
}
