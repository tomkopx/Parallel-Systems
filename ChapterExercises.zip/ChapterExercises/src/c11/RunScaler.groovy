package c11

import org.jcsp.lang.*
import org.jcsp.groovy.*
import org.jcsp.groovy.plugAndPlay.*   
  
def data = Channel.createOne2One()
def timedData = Channel.createOne2One()
def scaledData = Channel.createOne2One()
def oldScale = Channel.createOne2One()
def newScale = Channel.createOne2One()
def pause = Channel.createOne2One()

def network = [ new GNumbers ( outChannel: data.out() ),
                new GFixedDelay ( delay: 1000, 
                		          inChannel: data.in(), 
                		          outChannel: timedData.out() ),
                new Scale ( inChannel: timedData.in(),
                            outChannel: scaledData.out(),
                            factor: oldScale.out(),
                            suspend: pause.in(),
                            injector: newScale.in(),
                            scaling: 2,
							multiplier: 2 ),
                new ControllerUI ( factor: oldScale.in(),
								   data: scaledData.in(),
                                   suspend: pause.out(),
                                   injector: newScale.out() )
				//Removed GPrint since output is now sent to ControllerUI
              ]
new PAR ( network ).run()                                                            
