package c11

import org.jcsp.lang.*
import org.jcsp.groovy.*

class Scale implements CSProcess {
  def int scaling
  def int multiplier
  def ChannelOutput outChannel
  def ChannelOutput factor
  def ChannelInput inChannel
  def ChannelInput suspend
  def ChannelInput injector
  
  void run () {
    def SECOND = 1000
    def DOUBLE_INTERVAL = 5 * SECOND
    def SUSPEND  = 0
    def INJECT   = 1
    def TIMER    = 2
    def INPUT    = 3
    
    def timer = new CSTimer()
    def scaleAlt = new ALT ( [ suspend, injector, timer, inChannel ] )
    
    def preCon = new boolean [4]
    preCon[SUSPEND] = true
    preCon[INJECT] = false
    preCon[TIMER] = true
    preCon[INPUT] = true
    def suspended = false
                                                                    
    def timeout = timer.read() + DOUBLE_INTERVAL
    timer.setAlarm ( timeout )
	
	outChannel.write("Original \t\t Scaled \n")
    
    while (true) {
      switch ( scaleAlt.priSelect(preCon) ) {
        case SUSPEND :	
          //  deal with suspend input
		  suspend.read()
		  factor.write(scaling.toString()) //Sending this to a label in UI
		  suspended = true
		  outChannel.write( "Suspended \n" ) //Instead of printing, send it to output field in UI
          break
        case INJECT:
          //  deal with inject input
		  scaling = Integer.valueOf(injector.read()) //Just so it doesn't read the input as ASCII
		  outChannel.write( "Injected scaling is $scaling \n" ) //Instead of printing, send it to output field in UI
		  suspended = false
		  timeout = timer.read() + DOUBLE_INTERVAL
		  timer.setAlarm( timeout )
          break
        case TIMER:
          //  deal with Timer input
		  timeout = timer.read() + DOUBLE_INTERVAL
		  timer.setAlarm( timeout )
		  scaling = scaling * multiplier
          outChannel.write( "Normal Timer: new scaling is ${scaling} \n" ) //Instead of printing, send it to output field in UI
          break
        case INPUT:
          //   deal with Input channel 
		  def inValue = inChannel.read()
		  def result = new ScaledData()
		  result.original = inValue
		  result.scaled = inValue * scaling
		  if(suspended) result.scaled = inValue 
		  outChannel.write( result )
          break
      } //end-switch
	  preCon[TIMER] = (!suspended) //If not suspended, timer is available
	  preCon[INJECT] = suspended //If suspended, injector is available
    } //end-while
  } //end-run
}