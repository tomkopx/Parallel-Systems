package c11

import java.io.Serializable;

class ScaledData implements Serializable {
	
  def int original
  def int scaled 
   
  def String toString () {
	  def s = " " + original + "\t\t" + scaled + "\n" //Added an end line at end for formatting
	  return s 
  }	
}
