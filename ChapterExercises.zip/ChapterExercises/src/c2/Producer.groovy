package c2

import org.jcsp.lang.CSProcess
import org.jcsp.lang.ChannelOutput
import phw.util.*

class Producer implements CSProcess {

  def ChannelOutput outChannel
  
  void run() {
    def i = 1000
    while ( i > 0 ) {
      i = Ask.Int ("next: ", -100, 100)
      outChannel.write (i)
    }
  }
}
