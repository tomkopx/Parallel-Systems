package c6

import org.jcsp.lang.*

import org.jcsp.groovy.*

class CreateSetsOfEightTest extends GroovyTestCase {
	
	void testSetsOfEight(){
		
			One2OneChannel connect1 = Channel.createOne2One()
			One2OneChannel connect2 = Channel.createOne2One()

			def GenerateSetsOfThree = new GenerateSetsOfThree ( outChannel: connect1.out() )
			def ListToStreamForTest = new ListToStreamForTest ( inChannel: connect1.in(), 
                    		           				outChannel: connect2.out() )
			def CreateSetsOfEight = new CreateSetsOfEight ( inChannel: connect2.in() )

			def processList = [ GenerateSetsOfThree, ListToStreamForTest, CreateSetsOfEight ]
			new PAR (processList).run()
			
			def expected = ListToStreamForTest.testList.subList(ListToStreamForTest.testList.size - 8, ListToStreamForTest.testList.size)
			def actual = CreateSetsOfEight.outList
			assertTrue(expected == actual)
	}
}

