package c6

import org.jcsp.lang.*

class ListToStreamForTest implements CSProcess{
	
	def ChannelInput inChannel
	def ChannelOutput outChannel
	def testList = []
	
	void run (){
		def inList = inChannel.read()
		while (inList[0] != -1) {
			// hint: output	list elements as single integers
			for(i in 0 ..< inList.size){
				outChannel.write(inList[i])
				testList = testList << inList[i] //To be used for testing
			}
			inList = inChannel.read()
		}
		outChannel.write(-1)
	}
}