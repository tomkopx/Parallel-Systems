package c8

// copyright 2012-13 Jon Kerridge
// Let's Do It In Parallel

import org.jcsp.lang.*
import org.jcsp.groovy.*


class Client implements CSProcess{  
	
  def ChannelInput receiveChannel
  def ChannelOutput requestChannel
  def clientNumber   
  def selectList = [ ] 
   
  void run () {
    def iterations = selectList.size
    println "Client $clientNumber has $iterations values in $selectList"
	
    for ( i in 0 ..< iterations) {
      def key = selectList[i]
	  def expected = key * 10
	  def test = "WRONG"
      requestChannel.write(key)
      def v = receiveChannel.read()
	  if (expected == v) test = "CORRECT"
	  println "Client $clientNumber requested a value at location $key \t The expected value is $expected \t The actual value is $v \t $test"
    }
	
    println "Client $clientNumber has finished"
  }
}