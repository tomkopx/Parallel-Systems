package c91
 
// copyright 2012-13 Jon Kerridge
// Let's Do It In Parallel


import org.jcsp.lang.*
import org.jcsp.groovy.*

class EventData implements Serializable, JCSPCopy {  
	
  def int source = 0
  def int data = 0
  def int missed = -1
  def test = "Incorrect"
   
  def copy() {
    def e = new EventData ( source: this.source, 
                            data: this.data, 
                            missed: this.missed,
							test: this.test )
    return e
  }  
  
  def String toString() {
    def s = "EventData -> [source: "
    s = s + source + ", data: "
    s = s + data + ", missed: " 
    s = s + missed + "]"
	s = s + " -- Testing missed data: " + test
    return s
  }   
    
}


