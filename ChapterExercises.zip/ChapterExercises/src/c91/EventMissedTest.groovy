package c91

import org.jcsp.lang.*
import org.jcsp.groovy.*

class EventMissedTest implements CSProcess {

	def ChannelInput inChannel
	def ChannelOutput outChannel
	
	public void run() {
		def e = inChannel.read().copy()
		//This is a real hacky way of creating previous data for the first value in
		def previous = e.data - 1
		while(true){
			def test = (e.data - previous) - 1
			if(test == e.missed) e.test = "Correct!"
			previous = e.data
			outChannel.write(e)
			e = inChannel.read().copy()
		}
		
	}

}
