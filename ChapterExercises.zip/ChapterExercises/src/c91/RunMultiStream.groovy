package c91

// copyright 2012-13 Jon Kerridge
// Let's Do It In Parallel
import org.jcsp.lang.*
import org.jcsp.groovy.*
import org.jcsp.groovy.plugAndPlay.*
import phw.util.Ask

def sources = Ask.Int ("Number of event sources between 1 and 9 ? ", 1, 9)

minTimes = [ 100, 200, 300, 400, 500, 100, 200, 300, 400 ]
maxTimes = [ 1000, 1500, 2000, 500, 600, 300, 600, 1000, 800 ]  
      
def es2ep = Channel.one2oneArray(sources)

ChannelInputList eventsList = new ChannelInputList (es2ep)

def sourcesList = ( 0 ..< sources).collect { i ->
            new EventSource ( source: i+1, 
                              outChannel: es2ep[i].out(),
                              minTime: minTimes[i],
                              maxTime: maxTimes[i] ) 
            }

def eventProcess = new EventProcessing ( eventStreams: eventsList,
                                          minTime: 100,
                                          maxTime: 4000 )

new PAR( sourcesList + eventProcess).run()