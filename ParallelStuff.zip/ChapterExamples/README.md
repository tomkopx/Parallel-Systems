This is the source for all the chapter examples used in the book
Using Concurrency and Parallelism Effectively by Jon Kerridge
Publisher bookboon.com