package c19.net2.netObjects








class ClientLocation implements Serializable {
	def processReceiveLocation
}
