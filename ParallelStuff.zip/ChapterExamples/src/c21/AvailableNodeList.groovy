package c21


class AvailableNodeList implements Serializable{

  def anl

}