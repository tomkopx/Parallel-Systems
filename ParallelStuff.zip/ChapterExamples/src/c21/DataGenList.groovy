package c21


class DataGenList implements Serializable{

  def dgl

}