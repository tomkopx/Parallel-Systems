package c21.net2








class DataGenList implements Serializable{

  def dgl // list of values sent by node to DataGenerator

}
