package c22.universalClasses








class Signal implements Serializable{
	def signal = -1
}

