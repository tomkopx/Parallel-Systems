package c24.Distributed.dataRecords

class MapEntry implements Serializable {
  int sequenceValue = 0
  def entryList = []
}
