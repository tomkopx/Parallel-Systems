package c24.Distributed.dataRecords

class MergeFileData implements Serializable {
  def source
  def Nvalue
}
