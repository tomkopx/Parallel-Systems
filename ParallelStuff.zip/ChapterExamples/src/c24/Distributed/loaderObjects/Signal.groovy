package c24.Distributed.loaderObjects








class Signal implements Serializable {
	def signal = -1
}
