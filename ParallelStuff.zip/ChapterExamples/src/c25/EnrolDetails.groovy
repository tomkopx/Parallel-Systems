package c25

import java.io.Serializable;

class EnrolDetails implements Serializable {
	def id = -1
}
