package c25

class SquareCoords implements Serializable {
	def location = []
}
